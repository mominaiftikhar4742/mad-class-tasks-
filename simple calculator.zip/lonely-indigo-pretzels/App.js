import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";

export default function App() {
  const [input, setInput] = useState("");

  const handlePress = (value) => {
    if (value === "C") {
      setInput("");
    } else if (value === "=") {
      try {
        setInput(eval(input).toString()); // Evaluate expression
      } catch (error) {
        setInput("Error");
      }
    } else {
      setInput(input + value);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.display}>{input || "0"}</Text>
      <View style={styles.row}>
        {["7", "8", "9", "/"].map((item) => (
          <CalcButton key={item} label={item} onPress={() => handlePress(item)} />
        ))}
      </View>
      <View style={styles.row}>
        {["4", "5", "6", "*"].map((item) => (
          <CalcButton key={item} label={item} onPress={() => handlePress(item)} />
        ))}
      </View>
      <View style={styles.row}>
        {["1", "2", "3", "-"].map((item) => (
          <CalcButton key={item} label={item} onPress={() => handlePress(item)} />
        ))}
      </View>
      <View style={styles.row}>
        {["C", "0", "=", "+"].map((item) => (
          <CalcButton key={item} label={item} onPress={() => handlePress(item)} />
        ))}
      </View>
    </View>
  );
}

const CalcButton = ({ label, onPress }) => (
  <TouchableOpacity style={styles.button} onPress={onPress}>
    <Text style={styles.buttonText}>{label}</Text>
  </TouchableOpacity>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
  },
  display: {
    fontSize: 40,
    marginBottom: 20,
    backgroundColor: "#fff",
    width: "90%",
    textAlign: "right",
    padding: 15,
    borderRadius: 10,
    elevation: 3,
  },
  row: {
    flexDirection: "row",
    marginBottom: 10,
  },
  button: {
    width: 70,
    height: 70,
    justifyContent: "center",
    alignItems: "center",
    margin: 5,
    backgroundColor: "#3498db",
    borderRadius: 10,
  },
  buttonText: {
    fontSize: 24,
    color: "#fff",
  },
});

